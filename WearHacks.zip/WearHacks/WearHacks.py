from visual import *
'''myo     ready, floor/ceiling, on/off
beacon      ready, 0/1/2/3'''

light = 0

'''mazhar: light 0/1/2/3, 0/1,    0/1
                    room    floor   on/off'''

roof = box(pos=(0,5,0), size=(10,0.2,10), color=color.red, material=materials.wood)
floor = box(pos=(0,-5,0), size=(10,0.2,10), color=color.white, material=materials.wood)
wall1 = box(pos=(-2.5,0,-0.1), size=(5,10,0.2), color=color.blue)
wall2 = box(pos=(-2.5,0,0.1), size=(5,10,0.2), color=color.green)
wall3 = box(pos=(2.5,0,-0.1), size=(5,10,0.2), color=color.orange)
wall4 = box(pos=(2.5,0,0.1), size=(5,10,0.2), color=color.white)
wall5 = box(pos=(-0.1,0,-2.5), size=(0.2,10,5), color=color.blue)
wall6 = box(pos=(0.1,0,-2.5), size=(0.2,10,5), color=color.orange)
wall7 = box(pos=(-0.1,0,2.5), size=(0.2,10,5), color=color.green)
wall8 = box(pos=(0.1,0,2.5), size=(0.2,10,5), color=color.white)
marker1 = text(pos=(2, -0.3, 0.3), text="4",  height = 2.0, color=color.black)
marker2 = text(pos=(0.3, -0.3, -2), text="2",  height = 2.0, color=color.black, axis=(0,0, -1))
marker3 = text(pos=(-2, -0.3, -0.3), text="1",  height = 2.0, color=color.black, axis=(-1,0, 0))
marker4 = text(pos=(-0.3, -0.3, 2), text="3",  height = 2.0, color=color.black, axis=(0,0, 1))
Name = text(pos=(-5.8, 6, 0), text="Team Donkey Kong", color=color.white, axis=(1,0,0), size=0.55)

light10 = sphere(pos = (-2,-3,-2), radius = 0.4, color = color.black)
light11 = sphere(pos = (-2,3,-2), radius = 0.4, color = color.black)
light20 = sphere(pos = (2,-3,-2), radius = 0.4, color = color.black)
light21 = sphere(pos = (2,3,-2), radius = 0.4, color = color.black)
light30 = sphere(pos = (-2,-3,2), radius = 0.4, color = color.black)
light31 = sphere(pos = (-2,3,2), radius = 0.4, color = color.black)
light40 = sphere(pos = (2,3,2), radius = 0.4, color = color.black)
light41 = sphere(pos = (2,-3,2), radius = 0.4, color = color.black)

while 1:
    rate(300)
    myo = open('sdk/samples/outputMyo.txt', 'r')
    beacon = open('noble-master/examples/outputBeacon.txt', 'r')
    myostring = myo.readline()
    beaconstring = beacon.readline()
    if myostring[0:6] == 'Ready ':
        if beaconstring[0:6] == 'Ready ':
            light = int(beaconstring[6] + myostring[6:8])


    if(light<200):
        if((light-110)<0):
            if (light == 100):
                light10.color = color.black
            elif (light == 101):
                light10.color = color.yellow
        else:
            if (light == 110):
                light11.color = color.black
            elif (light == 111):
                light11.color = color.yellow

    elif(light<300):
        if((light-210)<0):
            if (light == 200):
                light20.color = color.black
            elif (light == 201):
                light20.color = color.yellow
        else:
            if (light == 210):
                light21.color = color.black
            elif (light == 211):
                light21.color = color.yellow

    elif(light<400):
        if((light-310)<0):
            if (light == 300):
                light30.color = color.black
            elif (light == 301):
                light30.color = color.yellow
        else:
            if (light == 310):
                light31.color = color.black
            elif (light == 311):
                light31.color = color.yellow
    elif(light<500):
        if((light-410)<0):
            if (light == 400):
                light40.color = color.black
            elif (light == 401):
                light40.color = color.yellow

        else:
            if (light == 410):
                light41.color =color.black
            elif (light == 411):
                light41.color = color.yellow

    myo.close()
    beacon.close()

