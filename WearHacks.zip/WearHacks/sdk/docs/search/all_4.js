var searchData=
[
  ['getting_20started',['Getting Started',['../getting-started.html',1,'index']]]
];
