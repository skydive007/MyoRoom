/*
  Continously scans for peripherals and prints out message when they enter/exit

    In range criteria:      RSSI < threshold
    Out of range criteria:  lastSeen > grace period

  based on code provided by: Mattias Ask (http://www.dittlof.com)
*/
var noble = require('../index');
var fs = require('fs');

var RSSI_THRESHOLD    = -70;
var EXIT_GRACE_PERIOD = 2000; // milliseconds

var inRange = [];

noble.on('discover', function(peripheral) {
  if (peripheral.rssi < RSSI_THRESHOLD) {
    // ignore
    return;
  }

  var id = peripheral.id;
  var entered = !inRange[id];

  if (entered) {
    inRange[id] = {
      peripheral: peripheral
    };

    
    var serviceData = peripheral.advertisement.serviceData;
         
         minor = JSON.stringify(peripheral.advertisement.manufacturerData.toString('hex'));
         minor = minor.substring(45,49);
         if(minor == "59e3"){
         index = 1;   //Green
         }
         else if(minor == "966b"){
         index = 2;    //Blue w sticker
         }
         else if(minor == "f79a"){
         index = 3;    //Blue w/o sticker
         }
         else if(minor == "5379"){
         index = 4;   //Light Blue
         }
         console.log(index);
    fs.writeFile('outputBeacon.txt', "Ready " + index + ".", function(err){
                      if(err) return console.log(err);
                      });
  }

  inRange[id].lastSeen = Date.now();
});

setInterval(function() {
  for (var id in inRange) {
    if (inRange[id].lastSeen < (Date.now() - EXIT_GRACE_PERIOD)) {
      var peripheral = inRange[id].peripheral;

      console.log('"' + peripheral.advertisement.localName + '" exited (RSSI ' + peripheral.rssi + ') ' + new Date());

      delete inRange[id];
    }
  }
}, EXIT_GRACE_PERIOD / 2);

noble.on('stateChange', function(state) {
  if (state === 'poweredOn') {
    noble.startScanning([], true);
  } else {
    noble.stopScanning();
  }

});
