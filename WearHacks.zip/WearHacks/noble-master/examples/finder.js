var noble = require('../index');
var fs = require('fs');

noble.on('stateChange', function(state) {
  if (state === 'poweredOn') {
    noble.startScanning();
  } else {
    noble.stopScanning();
  }
});

var array = [-200, -200, -200, -200];
var max, ind, rssi, minor;
noble.on('discover', function(peripheral) {
  console.log('peripheral discovered (' + peripheral.id +
              ' with address <' + peripheral.address +  ', ' + peripheral.addressType + '>,' +
              ' connectable ' + peripheral.connectable + ',' +
              ' RSSI ' + peripheral.rssi + ':');
  console.log('\thello my local name is:');
  console.log('\t\t' + peripheral.advertisement.localName);
  console.log('\tcan I interest you in any of the following advertised services:');
  console.log('\t\t' + JSON.stringify(peripheral.advertisement.serviceUuids));

  var serviceData = peripheral.advertisement.serviceData;
         rssi = peripheral.rssi;
         minor = JSON.stringify(peripheral.advertisement.manufacturerData.toString('hex'));
         minor = minor.substring(45,49);
         if(minor == "59e3"){
         array[0] = rssi;   //Green
         }
         else if(minor == "966b"){
         array[1] = rssi;   //Blue w sticker
         }
         else if(minor == "f79a"){
         array[2] = rssi;   //Blue w/o sticker
         }
         else if(minor == "5379"){
         array[3] = rssi;   //Light Blue
         }

  if (serviceData && serviceData.length) {
    console.log('\there is my service data:');
    for (var i in serviceData) {
         console.log('\t\t' + JSON.stringify(serviceData[i].uuid) + ': ' + JSON.stringify(serviceData[i].data.toString('hex')));
    }
  }
  if (peripheral.advertisement.manufacturerData) {
    console.log('\there is my manufacturer data:');
             console.log('\t\t' + JSON.stringify(peripheral.advertisement.manufacturerData.toString('hex')));
         console.log(minor);
  }
  if (peripheral.advertisement.txPowerLevel !== undefined) {
    console.log('\tmy TX power level is:');
    console.log('\t\t' + peripheral.advertisement.txPowerLevel);
  }
         max = Math.max(array[0],array[1],array[2],array[3]);
         index = array.indexOf(max) + 1;
         console.log('The smallest value is:' + max + '\t\t' + 'The smallest index is:' + index);
         fs.writeFile('outputBeacon.txt', "Ready " + index + ".", function(err){
                      if(err) return console.log(err);
                      });
  console.log();
});

